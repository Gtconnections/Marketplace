import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export async function Nav() {
  let user = null;
  try {
    const supabase = await createClient();
    const {
      data: { user: u },
    } = await supabase.auth.getUser();
    user = u;
  } catch {
    // Supabase no configurado/alcanzable: mostramos la nav como invitado.
  }

  return (
    <header className="border-b border-[var(--border)] bg-[var(--surface)]">
      <nav className="container-page flex items-center justify-between h-16">
        <Link href="/" className="font-bold text-lg text-[var(--foreground)] no-underline">
          Marketplace
        </Link>

        <div className="flex items-center gap-3 text-sm">
          <Link href="/" className="muted no-underline hover:text-[var(--foreground)]">
            Explorar
          </Link>

          {user ? (
            <>
              <Link href="/dashboard" className="muted no-underline hover:text-[var(--foreground)]">
                Mis suscripciones
              </Link>
              <Link href="/vendor" className="btn btn-outline">
                Vender
              </Link>
              <form action="/auth/signout" method="post">
                <button type="submit" className="btn btn-outline">
                  Salir
                </button>
              </form>
            </>
          ) : (
            <>
              <Link href="/login" className="muted no-underline hover:text-[var(--foreground)]">
                Entrar
              </Link>
              <Link href="/signup" className="btn btn-primary">
                Crear cuenta
              </Link>
            </>
          )}
        </div>
      </nav>
    </header>
  );
}
