"use client";

import { useActionState } from "react";
import { becomeVendor, type ActionState } from "@/lib/actions/vendor";

export function BecomeVendorForm() {
  const [state, formAction, pending] = useActionState<ActionState, FormData>(
    becomeVendor,
    undefined,
  );

  return (
    <div className="card max-w-lg">
      <h2 className="text-xl font-bold mb-1">Abre tu tienda</h2>
      <p className="muted text-sm mb-6">
        Crea tu perfil de vendedor para empezar a ofrecer servicios.
      </p>
      <form action={formAction} className="flex flex-col gap-4">
        <div>
          <label className="label" htmlFor="display_name">
            Nombre de la tienda
          </label>
          <input id="display_name" name="display_name" className="input" required />
        </div>
        <div>
          <label className="label" htmlFor="bio">
            Descripción (opcional)
          </label>
          <textarea id="bio" name="bio" className="textarea" rows={3} />
        </div>
        {state?.error && (
          <p className="text-[var(--danger)] text-sm">{state.error}</p>
        )}
        <button type="submit" disabled={pending} className="btn btn-primary">
          {pending ? "Creando…" : "Crear tienda"}
        </button>
      </form>
    </div>
  );
}
