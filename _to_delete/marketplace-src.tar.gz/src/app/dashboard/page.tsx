import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { formatMoney, intervalLabel } from "@/lib/utils";
import type { Plan, Service, Vendor } from "@/lib/types";

export const dynamic = "force-dynamic";

const STATUS_LABEL: Record<string, string> = {
  active: "Activa",
  trialing: "Prueba",
  past_due: "Pago pendiente",
  canceled: "Cancelada",
  incomplete: "Incompleta",
  unpaid: "Impaga",
};

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: subs } = await supabase
    .from("subscriptions")
    .select("*, service:services(*, vendor:vendors(*)), plan:plans(*)")
    .eq("customer_id", user!.id)
    .order("created_at", { ascending: false });

  const list = subs ?? [];

  return (
    <div className="container-page py-12">
      <h1 className="text-2xl font-bold mb-1">Mis suscripciones</h1>
      <p className="muted mb-8">Los servicios que has contratado.</p>

      {list.length === 0 ? (
        <div className="card muted">
          Aún no tienes suscripciones.{" "}
          <Link href="/" className="text-[var(--primary)]">
            Explora servicios
          </Link>
          .
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {list.map((sub) => {
            const service = sub.service as Service & { vendor: Vendor };
            const plan = sub.plan as Plan;
            return (
              <div key={sub.id} className="card flex items-center justify-between">
                <div>
                  <h3 className="font-semibold">{service?.title}</h3>
                  <p className="muted text-sm">
                    {service?.vendor?.display_name} · {plan?.name}
                  </p>
                  {sub.current_period_end && (
                    <p className="muted text-xs mt-1">
                      Renueva:{" "}
                      {new Date(sub.current_period_end).toLocaleDateString("es")}
                    </p>
                  )}
                </div>
                <div className="text-right">
                  <span
                    className={
                      sub.status === "active" || sub.status === "trialing"
                        ? "badge badge-success"
                        : "badge badge-muted"
                    }
                  >
                    {STATUS_LABEL[sub.status] ?? sub.status}
                  </span>
                  {plan && (
                    <p className="font-semibold mt-2">
                      {formatMoney(plan.amount, plan.currency)}
                      <span className="muted font-normal text-sm">
                        {intervalLabel(plan.interval)}
                      </span>
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
