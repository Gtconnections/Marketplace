"use client";

import { useActionState } from "react";
import Link from "next/link";
import { signUp, type AuthState } from "@/lib/actions/auth";

export default function SignupPage() {
  const [state, formAction, pending] = useActionState<AuthState, FormData>(
    signUp,
    undefined,
  );

  return (
    <div className="container-page py-16 max-w-md mx-auto">
      <div className="card">
        <h1 className="text-2xl font-bold mb-1">Crear cuenta</h1>
        <p className="muted text-sm mb-6">
          Regístrate para contratar o vender servicios.
        </p>

        <form action={formAction} className="flex flex-col gap-4">
          <div>
            <label className="label" htmlFor="full_name">
              Nombre
            </label>
            <input id="full_name" name="full_name" type="text" className="input" />
          </div>
          <div>
            <label className="label" htmlFor="email">
              Email
            </label>
            <input id="email" name="email" type="email" required className="input" />
          </div>
          <div>
            <label className="label" htmlFor="password">
              Contraseña
            </label>
            <input
              id="password"
              name="password"
              type="password"
              required
              minLength={6}
              className="input"
            />
          </div>

          {state?.error && (
            <p className="text-[var(--foreground)] text-sm bg-[color-mix(in_srgb,var(--primary)_10%,transparent)] p-3 rounded-lg">
              {state.error}
            </p>
          )}

          <button type="submit" disabled={pending} className="btn btn-primary">
            {pending ? "Creando…" : "Crear cuenta"}
          </button>
        </form>

        <p className="muted text-sm mt-5">
          ¿Ya tienes cuenta?{" "}
          <Link href="/login" className="text-[var(--primary)]">
            Entrar
          </Link>
        </p>
      </div>
    </div>
  );
}
