import type { Metadata } from "next";
import "./globals.css";
import { Nav } from "@/components/nav";

// La app es dinámica (sesión + datos en cada request); sin prerender estático.
export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Marketplace — Servicios y suscripciones",
  description:
    "Plataforma para ofrecer y contratar mentorías, membresías y servicios por suscripción.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="es" className="h-full antialiased">
      <body className="min-h-full flex flex-col">
        <Nav />
        <main className="flex-1">{children}</main>
        <footer className="border-t border-[var(--border)] mt-16">
          <div className="container-page py-8 muted text-sm">
            © {new Date().getFullYear()} Marketplace · Construido con Next.js,
            Supabase y Stripe Connect.
          </div>
        </footer>
      </body>
    </html>
  );
}
