import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { formatMoney, intervalLabel } from "@/lib/utils";
import { SERVICE_CATEGORIES } from "@/lib/config";
import { SubscribeButton } from "@/components/subscribe-button";
import type { Plan, Vendor } from "@/lib/types";

export const dynamic = "force-dynamic";

function categoryLabel(value: string) {
  return SERVICE_CATEGORIES.find((c) => c.value === value)?.label ?? value;
}

export default async function ServicePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const supabase = await createClient();

  const { data: service } = await supabase
    .from("services")
    .select("*, vendor:vendors(*), plans(*)")
    .eq("slug", slug)
    .eq("status", "published")
    .single();

  if (!service) notFound();

  const vendor = service.vendor as Vendor;
  const plans = ((service.plans as Plan[]) ?? [])
    .filter((p) => p.active)
    .sort((a, b) => a.amount - b.amount);

  const canPay = Boolean(vendor?.stripe_account_id && vendor?.charges_enabled);

  return (
    <div className="container-page py-12 grid gap-8 lg:grid-cols-[1fr_360px]">
      {/* Detalle */}
      <div>
        <Link href="/" className="muted text-sm no-underline">
          ← Volver
        </Link>
        <div className="mt-3 flex items-center gap-2">
          <span className="badge">{categoryLabel(service.category)}</span>
        </div>
        <h1 className="text-3xl font-bold mt-3">{service.title}</h1>
        <p className="muted mt-2">por {vendor?.display_name ?? "Vendedor"}</p>

        {service.description ? (
          <div className="prose mt-6 whitespace-pre-wrap leading-relaxed">
            {service.description}
          </div>
        ) : (
          <p className="muted mt-6">Este servicio aún no tiene descripción.</p>
        )}

        {vendor?.bio && (
          <div className="card mt-8">
            <h3 className="font-semibold mb-2">Sobre {vendor.display_name}</h3>
            <p className="muted text-sm whitespace-pre-wrap">{vendor.bio}</p>
          </div>
        )}
      </div>

      {/* Planes / suscripción */}
      <aside className="lg:sticky lg:top-6 h-fit">
        <div className="card">
          <h2 className="font-semibold mb-4">Planes</h2>

          {!canPay && (
            <p className="text-[var(--danger)] text-sm mb-4">
              Este vendedor todavía no completó su configuración de pagos.
            </p>
          )}

          {plans.length === 0 ? (
            <p className="muted text-sm">No hay planes disponibles.</p>
          ) : (
            <div className="flex flex-col gap-4">
              {plans.map((plan) => (
                <div key={plan.id} className="border border-[var(--border)] rounded-xl p-4">
                  <div className="flex items-baseline justify-between">
                    <span className="font-semibold">{plan.name}</span>
                    <span className="font-bold">
                      {formatMoney(plan.amount, plan.currency)}
                      <span className="muted font-normal text-sm">
                        {intervalLabel(plan.interval)}
                      </span>
                    </span>
                  </div>
                  <div className="mt-3">
                    <SubscribeButton
                      planId={plan.id}
                      label="Suscribirme"
                      disabled={!canPay || !plan.stripe_price_id}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </aside>
    </div>
  );
}
