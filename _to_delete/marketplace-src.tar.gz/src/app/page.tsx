import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { formatMoney, intervalLabel } from "@/lib/utils";
import { SERVICE_CATEGORIES } from "@/lib/config";
import type { Plan } from "@/lib/types";

export const dynamic = "force-dynamic";

function categoryLabel(value: string) {
  return SERVICE_CATEGORIES.find((c) => c.value === value)?.label ?? value;
}

/** Precio "desde" de un servicio (el plan más barato). */
function fromPrice(plans: Plan[]) {
  const active = plans.filter((p) => p.active);
  if (active.length === 0) return null;
  return active.reduce((min, p) => (p.amount < min.amount ? p : min), active[0]);
}

export default async function Home() {
  const supabase = await createClient();

  const { data: services } = await supabase
    .from("services")
    .select("*, vendor:vendors(*), plans(*)")
    .eq("status", "published")
    .order("created_at", { ascending: false });

  const list = services ?? [];

  return (
    <div>
      {/* Hero */}
      <section className="container-page pt-16 pb-10">
        <span className="badge">Servicios y suscripciones</span>
        <h1 className="text-4xl sm:text-5xl font-bold mt-4 max-w-2xl leading-tight">
          Encuentra mentorías, membresías y servicios por suscripción.
        </h1>
        <p className="muted text-lg mt-4 max-w-xl">
          Contrata directamente a expertos. Pago seguro y recurrente con Stripe.
        </p>
        <div className="flex gap-3 mt-6">
          <a href="#servicios" className="btn btn-primary">
            Explorar servicios
          </a>
          <Link href="/vendor" className="btn btn-outline">
            Quiero vender
          </Link>
        </div>
      </section>

      {/* Listado */}
      <section id="servicios" className="container-page py-6">
        <h2 className="text-xl font-semibold mb-5">
          {list.length > 0 ? "Servicios disponibles" : "Aún no hay servicios"}
        </h2>

        {list.length === 0 ? (
          <div className="card muted">
            Todavía no hay servicios publicados. Si eres vendedor,{" "}
            <Link href="/vendor" className="text-[var(--primary)]">
              crea el primero
            </Link>
            .
          </div>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((s) => {
              const plan = fromPrice((s.plans as Plan[]) ?? []);
              return (
                <Link
                  key={s.id}
                  href={`/services/${s.slug}`}
                  className="card no-underline text-[var(--foreground)] hover:border-[var(--primary)] transition-colors flex flex-col"
                >
                  <div className="flex items-center justify-between mb-3">
                    <span className="badge-muted badge">{categoryLabel(s.category)}</span>
                  </div>
                  <h3 className="font-semibold text-lg">{s.title}</h3>
                  <p className="muted text-sm mt-1">
                    por {s.vendor?.display_name ?? "Vendedor"}
                  </p>
                  {s.description && (
                    <p className="text-sm mt-3 line-clamp-3">{s.description}</p>
                  )}
                  <div className="mt-auto pt-4 font-semibold">
                    {plan ? (
                      <>
                        Desde {formatMoney(plan.amount, plan.currency)}
                        <span className="muted font-normal">
                          {intervalLabel(plan.interval)}
                        </span>
                      </>
                    ) : (
                      <span className="muted font-normal">Próximamente</span>
                    )}
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
