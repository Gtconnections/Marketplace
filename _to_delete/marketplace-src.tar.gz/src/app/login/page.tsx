"use client";

import { useActionState, Suspense } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { signIn, type AuthState } from "@/lib/actions/auth";

function LoginForm() {
  const searchParams = useSearchParams();
  const next = searchParams.get("next") ?? "/dashboard";
  const [state, formAction, pending] = useActionState<AuthState, FormData>(
    signIn,
    undefined,
  );

  return (
    <div className="container-page py-16 max-w-md mx-auto">
      <div className="card">
        <h1 className="text-2xl font-bold mb-1">Entrar</h1>
        <p className="muted text-sm mb-6">Accede a tu cuenta.</p>

        <form action={formAction} className="flex flex-col gap-4">
          <input type="hidden" name="next" value={next} />
          <div>
            <label className="label" htmlFor="email">
              Email
            </label>
            <input id="email" name="email" type="email" required className="input" />
          </div>
          <div>
            <label className="label" htmlFor="password">
              Contraseña
            </label>
            <input
              id="password"
              name="password"
              type="password"
              required
              className="input"
            />
          </div>

          {state?.error && (
            <p className="text-[var(--danger)] text-sm">{state.error}</p>
          )}

          <button type="submit" disabled={pending} className="btn btn-primary">
            {pending ? "Entrando…" : "Entrar"}
          </button>
        </form>

        <p className="muted text-sm mt-5">
          ¿No tienes cuenta?{" "}
          <Link href="/signup" className="text-[var(--primary)]">
            Crear cuenta
          </Link>
        </p>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense>
      <LoginForm />
    </Suspense>
  );
}
