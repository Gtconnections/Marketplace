/**
 * Configuración central de la plataforma.
 * Valores derivados de variables de entorno con defaults seguros.
 */

export const siteUrl =
  process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "") ?? "http://localhost:3000";

/** Comisión de la plataforma sobre cada suscripción, en porcentaje (0-100). */
export const platformFeePercent = Number(process.env.PLATFORM_FEE_PERCENT ?? "10");

/** Categorías de servicios que admite el marketplace (servicios y suscripciones). */
export const SERVICE_CATEGORIES = [
  { value: "mentoria", label: "Mentoría" },
  { value: "membresia", label: "Membresía / Comunidad" },
  { value: "coaching", label: "Coaching" },
  { value: "consultoria", label: "Consultoría" },
  { value: "curso", label: "Curso / Programa" },
  { value: "otro", label: "Otro" },
] as const;

export type ServiceCategory = (typeof SERVICE_CATEGORIES)[number]["value"];

/** Intervalos de cobro soportados. */
export const BILLING_INTERVALS = [
  { value: "month", label: "Mensual" },
  { value: "year", label: "Anual" },
] as const;

export type BillingInterval = (typeof BILLING_INTERVALS)[number]["value"];
