"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { stripe } from "@/lib/stripe";
import { slugify, shortId } from "@/lib/utils";

export type ActionState = { error?: string; ok?: boolean } | undefined;

/** Convierte al usuario actual en vendedor (crea su tienda). */
export async function becomeVendor(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const displayName = String(formData.get("display_name") ?? "").trim();
  if (!displayName) return { error: "Pon un nombre de tienda." };

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/vendor");

  const { error } = await supabase.from("vendors").insert({
    profile_id: user.id,
    display_name: displayName,
    slug: `${slugify(displayName)}-${shortId()}`,
    bio: String(formData.get("bio") ?? "").trim() || null,
  });
  if (error) return { error: error.message };

  await supabase.from("profiles").update({ role: "vendor" }).eq("id", user.id);

  revalidatePath("/vendor");
  redirect("/vendor");
}

/**
 * Crea un servicio con un plan de suscripción.
 * Si el vendedor ya está conectado a Stripe, crea Product + Price en su
 * cuenta conectada (direct charges).
 */
export async function createServiceWithPlan(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/vendor/services/new");

  const { data: vendor } = await supabase
    .from("vendors")
    .select("*")
    .eq("profile_id", user.id)
    .single();
  if (!vendor) return { error: "Primero crea tu tienda de vendedor." };

  const title = String(formData.get("title") ?? "").trim();
  const description = String(formData.get("description") ?? "").trim();
  const category = String(formData.get("category") ?? "otro");
  const planName = String(formData.get("plan_name") ?? "Plan").trim();
  const interval = String(formData.get("interval") ?? "month");
  const priceUsd = Number(formData.get("price") ?? "0");

  if (!title) return { error: "El título es obligatorio." };
  if (!priceUsd || priceUsd <= 0) return { error: "Pon un precio válido." };

  const amount = Math.round(priceUsd * 100); // a centavos

  // 1) Crear el servicio (borrador).
  const { data: service, error: sErr } = await supabase
    .from("services")
    .insert({
      vendor_id: vendor.id,
      title,
      slug: `${slugify(title)}-${shortId()}`,
      description: description || null,
      category,
      status: "draft",
    })
    .select()
    .single();
  if (sErr || !service) return { error: sErr?.message ?? "No se pudo crear el servicio." };

  // 2) Crear Product + Price en Stripe (en la cuenta conectada del vendedor).
  let stripeProductId: string | null = null;
  let stripePriceId: string | null = null;

  if (vendor.stripe_account_id) {
    try {
      const product = await stripe.products.create(
        { name: title, metadata: { service_id: service.id } },
        { stripeAccount: vendor.stripe_account_id },
      );
      const price = await stripe.prices.create(
        {
          product: product.id,
          unit_amount: amount,
          currency: "usd",
          recurring: { interval: interval === "year" ? "year" : "month" },
        },
        { stripeAccount: vendor.stripe_account_id },
      );
      stripeProductId = product.id;
      stripePriceId = price.id;
    } catch (err) {
      const msg = err instanceof Error ? err.message : "error en Stripe";
      return { error: `Servicio creado, pero falló el precio en Stripe: ${msg}` };
    }
  }

  // 3) Crear el plan.
  const { error: pErr } = await supabase.from("plans").insert({
    service_id: service.id,
    name: planName,
    interval,
    amount,
    currency: "usd",
    stripe_product_id: stripeProductId,
    stripe_price_id: stripePriceId,
  });
  if (pErr) return { error: pErr.message };

  revalidatePath("/vendor");
  redirect("/vendor");
}

/** Publica o despublica un servicio. */
export async function toggleServiceStatus(formData: FormData): Promise<void> {
  const serviceId = String(formData.get("service_id") ?? "");
  const next = String(formData.get("next_status") ?? "published");

  const supabase = await createClient();
  await supabase
    .from("services")
    .update({ status: next === "published" ? "published" : "draft" })
    .eq("id", serviceId);

  revalidatePath("/vendor");
  revalidatePath("/");
}
