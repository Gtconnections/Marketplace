/**
 * Tipos del dominio, alineados con el esquema de la base de datos
 * (supabase/migrations/0001_init.sql).
 */

export type UserRole = "customer" | "vendor" | "admin";
export type ServiceStatus = "draft" | "published";
export type PlanInterval = "month" | "year";
export type SubscriptionStatus =
  | "active"
  | "trialing"
  | "past_due"
  | "canceled"
  | "incomplete"
  | "incomplete_expired"
  | "unpaid";

export interface Profile {
  id: string;
  email: string | null;
  full_name: string | null;
  role: UserRole;
  created_at: string;
}

export interface Vendor {
  id: string;
  profile_id: string;
  display_name: string;
  slug: string;
  bio: string | null;
  stripe_account_id: string | null;
  charges_enabled: boolean;
  created_at: string;
}

export interface Service {
  id: string;
  vendor_id: string;
  title: string;
  slug: string;
  description: string | null;
  category: string;
  cover_image_url: string | null;
  status: ServiceStatus;
  created_at: string;
}

export interface Plan {
  id: string;
  service_id: string;
  name: string;
  interval: PlanInterval;
  amount: number; // en centavos
  currency: string;
  stripe_product_id: string | null;
  stripe_price_id: string | null;
  active: boolean;
  created_at: string;
}

export interface Subscription {
  id: string;
  customer_id: string;
  plan_id: string;
  service_id: string;
  vendor_id: string;
  stripe_subscription_id: string | null;
  stripe_customer_id: string | null;
  status: SubscriptionStatus;
  current_period_end: string | null;
  created_at: string;
}

// Tipos compuestos usados en la UI
export interface ServiceWithVendorAndPlans extends Service {
  vendor: Vendor;
  plans: Plan[];
}
