/**
 * Sistema de diseño — helpers de clases de Tailwind.
 *
 * Centralizamos aquí los estilos base de las primitivas (botón, campo, badge,
 * card) para mantener jerarquía tipográfica, espaciado y micro-interacciones
 * consistentes en toda la app. Las páginas componen estas primitivas con
 * utilidades de Tailwind. Paleta: neutros zinc + acento indigo (alto contraste).
 */

/** Une clases condicionalmente (mini-clsx). */
export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}

/** Contenedor centrado con padding responsivo consistente. */
export const container = "mx-auto w-full max-w-6xl px-5 sm:px-6";

type ButtonVariant = "primary" | "secondary" | "ghost" | "danger";
type ButtonSize = "sm" | "md" | "lg";

const BUTTON_BASE =
  "inline-flex items-center justify-center gap-2 rounded-lg font-medium " +
  "transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 " +
  "focus-visible:ring-offset-2 focus-visible:ring-offset-white " +
  "disabled:opacity-50 disabled:pointer-events-none select-none whitespace-nowrap";

const BUTTON_VARIANTS: Record<ButtonVariant, string> = {
  primary:
    "bg-indigo-600 text-white shadow-sm hover:bg-indigo-700 active:bg-indigo-800 " +
    "hover:shadow-md hover:-translate-y-px focus-visible:ring-indigo-500",
  secondary:
    "border border-zinc-200 bg-white text-zinc-900 shadow-sm hover:bg-zinc-50 " +
    "hover:border-zinc-300 focus-visible:ring-zinc-400",
  ghost:
    "text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100 focus-visible:ring-zinc-300",
  danger:
    "bg-red-600 text-white shadow-sm hover:bg-red-700 focus-visible:ring-red-500",
};

const BUTTON_SIZES: Record<ButtonSize, string> = {
  sm: "h-9 px-3.5 text-sm",
  md: "h-11 px-5 text-sm",
  lg: "h-12 px-6 text-base",
};

/** Clases para un botón (o un <Link> con apariencia de botón). */
export function btn(
  variant: ButtonVariant = "primary",
  size: ButtonSize = "md",
  extra?: string,
): string {
  return cn(BUTTON_BASE, BUTTON_VARIANTS[variant], BUTTON_SIZES[size], extra);
}

/** Card de superficie. `hover` añade elevación en interacción. */
export function card(hover = false, extra?: string): string {
  return cn(
    "rounded-2xl border border-zinc-200 bg-white shadow-sm",
    hover &&
      "transition-all duration-200 hover:shadow-md hover:-translate-y-0.5 hover:border-zinc-300",
    extra,
  );
}

/** Campo de formulario (input / select / textarea). */
export const inputCls =
  "w-full rounded-lg border border-zinc-200 bg-white px-3.5 py-2.5 text-sm " +
  "text-zinc-900 placeholder:text-zinc-400 shadow-sm transition-all duration-200 " +
  "focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none";

/** Etiqueta de campo. */
export const labelCls = "block text-sm font-medium text-zinc-700 mb-1.5";

type BadgeVariant = "brand" | "neutral" | "success" | "warning";

const BADGE_VARIANTS: Record<BadgeVariant, string> = {
  brand: "bg-indigo-50 text-indigo-700 ring-indigo-600/10",
  neutral: "bg-zinc-100 text-zinc-600 ring-zinc-500/10",
  success: "bg-emerald-50 text-emerald-700 ring-emerald-600/10",
  warning: "bg-amber-50 text-amber-700 ring-amber-600/10",
};

/** Etiqueta/píldora de estado. */
export function badge(variant: BadgeVariant = "neutral", extra?: string): string {
  return cn(
    "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset",
    BADGE_VARIANTS[variant],
    extra,
  );
}
