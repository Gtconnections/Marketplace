import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { Brand } from "@/components/brand";
import { btn, container, cn } from "@/lib/ui";

export async function Nav() {
  let user = null;
  try {
    const supabase = await createClient();
    const {
      data: { user: u },
    } = await supabase.auth.getUser();
    user = u;
  } catch {
    // Supabase no configurado/alcanzable: mostramos la nav como invitado.
  }

  const linkCls =
    "text-sm font-medium text-zinc-600 transition-colors duration-200 hover:text-zinc-900";

  return (
    <header className="sticky top-0 z-40 border-b border-zinc-200/80 bg-white/80 backdrop-blur-md">
      <nav className={cn(container, "flex h-16 items-center justify-between")}>
        <Brand />

        <div className="flex items-center gap-2 sm:gap-4">
          <Link href="/" className={cn(linkCls, "hidden sm:inline")}>
            Explorar
          </Link>

          {user ? (
            <>
              <Link href="/dashboard" className={cn(linkCls, "hidden sm:inline")}>
                Mis suscripciones
              </Link>
              <Link href="/vendor" className={btn("secondary", "sm")}>
                Vender
              </Link>
              <form action="/auth/signout" method="post">
                <button type="submit" className={btn("ghost", "sm")}>
                  Salir
                </button>
              </form>
            </>
          ) : (
            <>
              <Link href="/login" className={linkCls}>
                Entrar
              </Link>
              <Link href="/signup" className={btn("primary", "sm")}>
                Crear cuenta
              </Link>
            </>
          )}
        </div>
      </nav>
    </header>
  );
}
