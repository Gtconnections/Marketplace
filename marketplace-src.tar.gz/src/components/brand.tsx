import Link from "next/link";

/** Marca del marketplace: mark con gradiente + wordmark. */
export function Brand() {
  return (
    <Link href="/" className="group inline-flex items-center gap-2.5">
      <span
        className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-indigo-500 to-violet-600 text-sm font-bold text-white shadow-sm transition-transform duration-200 group-hover:scale-105"
        aria-hidden
      >
        M
      </span>
      <span className="text-[15px] font-semibold tracking-tight text-zinc-900">
        Marketplace
      </span>
    </Link>
  );
}
