import type { Metadata } from "next";
import "./globals.css";
import { Nav } from "@/components/nav";
import { container } from "@/lib/ui";

// La app es dinámica (sesión + datos en cada request); sin prerender estático.
export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Marketplace — Servicios y suscripciones",
  description:
    "Plataforma para ofrecer y contratar mentorías, membresías y servicios por suscripción.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="es" className="h-full antialiased">
      <body className="flex min-h-full flex-col bg-zinc-50 text-zinc-900">
        <Nav />
        <main className="flex-1">{children}</main>
        <footer className="mt-20 border-t border-zinc-200 bg-white">
          <div
            className={`${container} flex flex-col gap-2 py-8 text-sm text-zinc-500 sm:flex-row sm:items-center sm:justify-between`}
          >
            <p>© {new Date().getFullYear()} Marketplace</p>
            <p className="text-zinc-400">
              Construido con Next.js, Supabase y Stripe Connect.
            </p>
          </div>
        </footer>
      </body>
    </html>
  );
}
