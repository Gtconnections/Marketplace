import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { formatMoney, intervalLabel } from "@/lib/utils";
import { SERVICE_CATEGORIES } from "@/lib/config";
import { SubscribeButton } from "@/components/subscribe-button";
import { container, card, badge, cn } from "@/lib/ui";
import type { Plan, Vendor } from "@/lib/types";

export const dynamic = "force-dynamic";

function categoryLabel(value: string) {
  return SERVICE_CATEGORIES.find((c) => c.value === value)?.label ?? value;
}

export default async function ServicePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const supabase = await createClient();

  const { data: service } = await supabase
    .from("services")
    .select("*, vendor:vendors(*), plans(*)")
    .eq("slug", slug)
    .eq("status", "published")
    .single();

  if (!service) notFound();

  const vendor = service.vendor as Vendor;
  const plans = ((service.plans as Plan[]) ?? [])
    .filter((p) => p.active)
    .sort((a, b) => a.amount - b.amount);

  const canPay = Boolean(vendor?.stripe_account_id && vendor?.charges_enabled);

  return (
    <div className={cn(container, "py-12")}>
      <Link
        href="/"
        className="inline-flex items-center gap-1.5 text-sm font-medium text-zinc-500 transition-colors hover:text-zinc-900"
      >
        <span aria-hidden>←</span> Volver
      </Link>

      <div className="mt-6 grid gap-10 lg:grid-cols-[1fr_380px]">
        {/* Detalle */}
        <div>
          <span className={badge("brand")}>{categoryLabel(service.category)}</span>
          <h1 className="mt-4 text-4xl font-bold tracking-tight text-zinc-900">
            {service.title}
          </h1>
          <p className="mt-2 text-zinc-500">
            por{" "}
            <span className="font-medium text-zinc-700">
              {vendor?.display_name ?? "Vendedor"}
            </span>
          </p>

          {service.description ? (
            <p className="mt-8 whitespace-pre-wrap text-[15px] leading-7 text-zinc-700">
              {service.description}
            </p>
          ) : (
            <p className="mt-8 text-zinc-500">
              Este servicio aún no tiene descripción.
            </p>
          )}

          {vendor?.bio && (
            <div className={card(false, "mt-10 p-6")}>
              <h3 className="text-sm font-semibold text-zinc-900">
                Sobre {vendor.display_name}
              </h3>
              <p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-zinc-600">
                {vendor.bio}
              </p>
            </div>
          )}
        </div>

        {/* Planes / suscripción */}
        <aside className="lg:sticky lg:top-24 lg:h-fit">
          <div className={card(false, "p-6")}>
            <h2 className="text-sm font-semibold uppercase tracking-wide text-zinc-500">
              Planes
            </h2>

            {!canPay && (
              <div className={badge("warning", "mt-4")}>
                Pagos no configurados aún
              </div>
            )}

            {plans.length === 0 ? (
              <p className="mt-4 text-sm text-zinc-500">
                No hay planes disponibles.
              </p>
            ) : (
              <div className="mt-4 flex flex-col gap-3">
                {plans.map((plan, i) => (
                  <div
                    key={plan.id}
                    className={cn(
                      "rounded-xl border p-4 transition-all duration-200",
                      i === 0
                        ? "border-indigo-200 bg-indigo-50/40 ring-1 ring-inset ring-indigo-600/5"
                        : "border-zinc-200",
                    )}
                  >
                    <div className="flex items-baseline justify-between">
                      <span className="text-sm font-semibold text-zinc-900">
                        {plan.name}
                      </span>
                      <span className="text-right">
                        <span className="text-xl font-bold tracking-tight text-zinc-900">
                          {formatMoney(plan.amount, plan.currency)}
                        </span>
                        <span className="text-sm font-normal text-zinc-500">
                          {intervalLabel(plan.interval)}
                        </span>
                      </span>
                    </div>
                    <div className="mt-4">
                      <SubscribeButton
                        planId={plan.id}
                        label="Suscribirme"
                        disabled={!canPay || !plan.stripe_price_id}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}

            <p className="mt-5 flex items-center gap-1.5 text-xs text-zinc-400">
              <span aria-hidden>🔒</span> Pago seguro procesado por Stripe
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}
