import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { formatMoney, intervalLabel } from "@/lib/utils";
import { SERVICE_CATEGORIES } from "@/lib/config";
import { container, btn, card, badge, cn } from "@/lib/ui";
import type { Plan } from "@/lib/types";

export const dynamic = "force-dynamic";

function categoryLabel(value: string) {
  return SERVICE_CATEGORIES.find((c) => c.value === value)?.label ?? value;
}

function fromPrice(plans: Plan[]) {
  const active = plans.filter((p) => p.active);
  if (active.length === 0) return null;
  return active.reduce((min, p) => (p.amount < min.amount ? p : min), active[0]);
}

export default async function Home() {
  const supabase = await createClient();

  const { data: services } = await supabase
    .from("services")
    .select("*, vendor:vendors(*), plans(*)")
    .eq("status", "published")
    .order("created_at", { ascending: false });

  const list = services ?? [];

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-zinc-200 bg-white">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_120%_at_50%_-20%,rgba(99,102,241,0.12),transparent)]"
        />
        <div className={cn(container, "relative py-20 sm:py-28")}>
          <span className={badge("brand")}>Servicios y suscripciones</span>
          <h1 className="mt-5 max-w-3xl text-4xl font-bold leading-[1.1] tracking-tight text-zinc-900 sm:text-6xl">
            Contrata a los mejores expertos,{" "}
            <span className="bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
              por suscripción.
            </span>
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-zinc-600">
            Mentorías, membresías y servicios recurrentes en un solo lugar. Pago
            seguro con Stripe, sin complicaciones.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#servicios" className={btn("primary", "lg")}>
              Explorar servicios
            </a>
            <Link href="/vendor" className={btn("secondary", "lg")}>
              Quiero vender
            </Link>
          </div>
        </div>
      </section>

      {/* Listado */}
      <section id="servicios" className={cn(container, "py-16")}>
        <div className="mb-8 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight text-zinc-900">
              {list.length > 0 ? "Servicios disponibles" : "Aún no hay servicios"}
            </h2>
            {list.length > 0 && (
              <p className="mt-1 text-sm text-zinc-500">
                {list.length} {list.length === 1 ? "servicio" : "servicios"}{" "}
                publicados
              </p>
            )}
          </div>
        </div>

        {list.length === 0 ? (
          <div className={card(false, "flex flex-col items-center gap-3 p-12 text-center")}>
            <p className="text-zinc-600">Todavía no hay servicios publicados.</p>
            <Link href="/vendor" className={btn("primary", "md")}>
              Publica el primero
            </Link>
          </div>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((s) => {
              const plan = fromPrice((s.plans as Plan[]) ?? []);
              return (
                <Link
                  key={s.id}
                  href={`/services/${s.slug}`}
                  className={card(true, "group flex flex-col p-6")}
                >
                  <div className="mb-4 flex items-center justify-between">
                    <span className={badge("neutral")}>
                      {categoryLabel(s.category)}
                    </span>
                  </div>
                  <h3 className="text-lg font-semibold tracking-tight text-zinc-900">
                    {s.title}
                  </h3>
                  <p className="mt-1 text-sm text-zinc-500">
                    por {s.vendor?.display_name ?? "Vendedor"}
                  </p>
                  {s.description && (
                    <p className="mt-3 line-clamp-2 text-sm leading-relaxed text-zinc-600">
                      {s.description}
                    </p>
                  )}
                  <div className="mt-6 flex items-center justify-between border-t border-zinc-100 pt-4">
                    <span className="text-sm font-semibold text-zinc-900">
                      {plan ? (
                        <>
                          Desde {formatMoney(plan.amount, plan.currency)}
                          <span className="font-normal text-zinc-500">
                            {intervalLabel(plan.interval)}
                          </span>
                        </>
                      ) : (
                        <span className="font-normal text-zinc-500">
                          Próximamente
                        </span>
                      )}
                    </span>
                    <span
                      aria-hidden
                      className="text-indigo-600 transition-transform duration-200 group-hover:translate-x-1"
                    >
                      →
                    </span>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
